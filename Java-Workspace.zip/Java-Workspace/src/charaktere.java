
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.*;


public class charaktere {
	//Spielcharaktere
	public static void main(String[] args) {
		
		//Quelldaten
		String[] subject={"http://shadowhearts.wikia.com/wiki/Shadow_Hearts",
				"http://shadowhearts.wikia.com/wiki/Shadow_Hearts:_Covenant",
				"http://shadowhearts.wikia.com/wiki/Shadow_Hearts:_From_the_New_World",
				"http://megamitensei.wikia.com/wiki/Shin_Megami_Tensei_III:_Nocturne",
				"http://megamitensei.wikia.com/wiki/Devil_Summoner:_Raidou_Kuzunoha_vs._King_Abaddon",
				"http://megamitensei.wikia.com/wiki/Devil_Summoner:_Raidou_Kuzunoha_vs._The_Soulless_Army",
				"http://megamitensei.wikia.com/wiki/Digital_Devil_Saga:_Avatar_Tuner",
				"http://megamitensei.wikia.com/wiki/Digital_Devil_Saga:_Avatar_Tuner_2",
				"http://megamitensei.wikia.com/wiki/Persona_3",
				"http://colosseumgame.wikia.com/wiki/Colosseum:_Road_to_Freedom",
				"http://http://de.metalgear.wikia.com/wiki/Metal_Gear_Solid_3:_Snake_Eater",
				"http://spyfiction.wikia.com/wiki/Spy_Fiction_Wiki",
				"http://snk.wikia.com/wiki/World_Heroes_(series)",
				"http://grandia.wikia.com/wiki/Grandia_III",
				"http://de.kingdomhearts.wikia.com/wiki/Kingdom_Hearts",
				"http://radiata.wikia.com/wiki/Radiata_Stories",
				"http://valkyrieprofile.wikia.com/wiki/Valkyrie_Profile_2:_Silmeria"};
		String[] subjectlabel={"Shadow Hearts",
				"Shadow Hearts: Covenant", 
				"Shadow Hearts: From the New World",
				"Shin Megami Tensei III: Nocturne ",
				"Shin Megami Tensei: Devil Summoner - Raidou Kuzunoha vs. the Soulless Army ",
				"Shin Megami Tensei: Devil Summoner 2 - Raidou Kuzunoha vs. King Abaddon ",
				"Shin Megami Tensei: Digital Devil Saga ",
				"Shin Megami Tensei: Digital Devil Saga 2 ",
				"Shin Megami Tensei: Persona 3 ",
				"Colosseum: Road to Freedom ",
				"Metal Gear Solid",
				"Spy Fiction",
				"World Heroes Anthology",
				"Grandia III",
				"Kingdom Hearts",
				"Radiata Stories",
				"Valkyrie Profile 2: Silmeria "};
		String[] link={"http://shadowhearts.wikia.com/wiki/Category:Shadow_Hearts_Characters",
				"http://shadowhearts.wikia.com/wiki/Category:Shadow_Hearts:_Covenant_Characters",
				"http://shadowhearts.wikia.com/wiki/Category:Shadow_Hearts:_From_the_New_World_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Shin_Megami_Tensei_III:_Nocturne_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Devil_Summoner:_Raidou_Kuzunoha_vs._King_Abaddon_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Devil_Summoner:_Raidou_Kuzunoha_vs._The_Soulless_Army_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Digital_Devil_Saga:_Avatar_Tuner_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Digital_Devil_Saga:_Avatar_Tuner_2_Characters",
				"http://megamitensei.wikia.com/wiki/Category:Persona_3_Characters",
				"http://colosseumgame.wikia.com/wiki/Category:Characters",
				"http://de.metalgear.wikia.com/wiki/Kategorie:Charaktere",
				"http://spyfiction.wikia.com/wiki/Category:Characters",
				"http://snk.wikia.com/wiki/World_Heroes_(series)",
				"http://grandia.wikia.com/wiki/Category:Grandia_III_Characters",
				"http://de.kingdomhearts.wikia.com/wiki/Kategorie:Kingdom_Hearts_Charaktere",
				"http://radiata.wikia.com/wiki/Category:Characters",
				"http://valkyrieprofile.wikia.com/wiki/Category:Character"};
		String[] grundterm={"http://shadowhearts.wikia.com",
				"http://shadowhearts.wikia.com",
				"http://shadowhearts.wikia.com",
				"http://megamitensei.wikia.com",
				"http://megamitensei.wikia.com",
				"http://megamitensei.wikia.com",
				"http://megamitensei.wikia.com",
				"http://megamitensei.wikia.com",
				"http://megamitensei.wikia.com",
				"http://colosseumgame.wikia.com",
				"http://de.metalgear.wikia.com",
				"http://spyfiction.wikia.com",
				"http://snk.wikia.com",
				"http://grandia.wikia.com",
				"http://de.kingdomhearts.wikia.com",
				"http://radiata.wikia.com",
				"http://valkyrieprofile.wikia.com"};
		String[] platzierung = {"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"section div article div div div div div div ul li a",
				"section div article div div div ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a",
				"tbody tr td ul li a"};
		
		String typ1="Spiel";
		String typ2="Charakter";
		String praedikat="hascharakter";
		
		try	{
			FileWriter fw = new FileWriter("Z:/Desktop/Semantic Web/rdf_format/Charaktere.rdf",false);//h�ngt Daten unten an Datei an 
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
			bw.append("\r\n");
			bw.append("<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
			bw.append("\r\n");
			bw.append("xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\"");
			bw.append("\r\n");
			bw.append("xmlns:xsd= \"http://www.w3.org/2001/XMLSchema#\"");
			bw.append("\r\n");
			bw.append("xmlns:dbp=\"http://dbpedia.org/property/\"");
			bw.append("\r\n");
			bw.append("xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\">");
			bw.append("\r\n");
			bw.append("\r\n");
			
			for(int i=0;i<17;i++){
			// hier wird die funktion rdf_maker aufgerufen, um Charaktere der obrigen Spiele zu parsen und in RDF-Format zu speichern 
			rdf_maker (link[i],subject[i],praedikat,subjectlabel[i], grundterm[i],typ1,typ2,platzierung[i],bw);
			}
			
			bw.append("</rdf:RDF>");
			bw.close();	
			
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}	
	
	static void rdf_maker (String link,String subject, String praedikat, String subjectlabel,String grundterm, String typ1, String typ2, String platzierung, BufferedWriter bw) {
		try	{
			Document doc = Jsoup.connect(link).get();
			Elements charaktere = doc.select(platzierung);
			
			String[] objectlabel=new String[charaktere.size()];
			String[] object=new String[charaktere.size()];
			
			for (int i=0;i<charaktere.size();i++){
				Elements charaktere2 = charaktere.eq(i);
				objectlabel[i] = charaktere2.attr("Title"); 
				object[i] = (grundterm+charaktere2.attr("Href")); 
				System.out.println(objectlabel[i]);
				
				//in Datei schreiben
				bw.append("<rdf:"+typ1+" rdf:about=\""+subject+"\">");
				bw.append("\r\n");
				bw.append("<rdfs:label xml:lang=\"de\">"+subjectlabel+"</rdfs:label>");
				bw.append("\r\n");
				bw.append("<dbp:"+praedikat+">");
				bw.append("\r\n");
				bw.append("<rdf:"+typ2+" rdf:about=\""+object[i]+"\"> <dbp:name>"+objectlabel[i]+"</dbp:name>");
				bw.append("\r\n");
				bw.append("</rdf:"+typ2+">");
				bw.append("\r\n");
				bw.append("</dbp:"+praedikat+">");
				bw.append("\r\n");
				bw.append("</rdf:"+typ1+">");
				bw.append("\r\n");
				bw.append("\r\n");
			}
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}
	
}
