
import java.io.*;


public class publisher {
	
	public static void main(String[] args) {
		
		String[] object={"http://shadowhearts.wikia.com/wiki/Shadow_Hearts",
				"http://shadowhearts.wikia.com/wiki/Shadow_Hearts:_Covenant",
				"http://shadowhearts.wikia.com/wiki/Shadow_Hearts:_From_the_New_World",
				"http://megamitensei.wikia.com/wiki/Shin_Megami_Tensei_III:_Nocturne",
				"http://megamitensei.wikia.com/wiki/Devil_Summoner:_Raidou_Kuzunoha_vs._King_Abaddon",
				"http://megamitensei.wikia.com/wiki/Devil_Summoner:_Raidou_Kuzunoha_vs._The_Soulless_Army",
				"http://megamitensei.wikia.com/wiki/Digital_Devil_Saga:_Avatar_Tuner",
				"http://megamitensei.wikia.com/wiki/Digital_Devil_Saga:_Avatar_Tuner_2",
				"http://megamitensei.wikia.com/wiki/Persona_3",
				"http://colosseumgame.wikia.com/wiki/Colosseum:_Road_to_Freedom",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Samurai_Warriors",
				"http://http://de.metalgear.wikia.com/wiki/Metal_Gear_Solid_3:_Snake_Eater",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_I:_Der_Wille_zur_Macht",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_II:_Jenseits_von_Gut_und_B%C3%B6se",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_III:_Also_sprach_Zarathustra",
				"http://spyfiction.wikia.com/wiki/Spy_Fiction_Wiki",
				"http://snk.wikia.com/wiki/World_Heroes_(series)",
				"http://grandia.wikia.com/wiki/Grandia_III",
				"http://de.kingdomhearts.wikia.com/wiki/Kingdom_Hearts",
				"http://radiata.wikia.com/wiki/Radiata_Stories",
				"http://valkyrieprofile.wikia.com/wiki/Valkyrie_Profile_2:_Silmeria"};
		
		String[] objectlabel={"Shadow Hearts",
				"Shadow Hearts: Covenant", 
				"Shadow Hearts: From the New World",
				"Shin Megami Tensei III: Nocturne ",
				"Shin Megami Tensei: Devil Summoner - Raidou Kuzunoha vs. the Soulless Army ",
				"Shin Megami Tensei: Devil Summoner 2 - Raidou Kuzunoha vs. King Abaddon ",
				"Shin Megami Tensei: Digital Devil Saga ",
				"Shin Megami Tensei: Digital Devil Saga 2 ",
				"Shin Megami Tensei: Persona 3 ",
				"Colosseum: Road to Freedom ",
				"Dynasty Warriors",
				"Kessen",
				"Warriors Orochi",
				"Samurai Warriors",
				"Metal Gear Solid",
				"Xenosaga: Episode I - Der Wille zur Macht",
				"Xenosaga: Episode II - Jenseits von Gut und B�se",
				"Xenosaga: Episode III - Also Sprach Zarathustra",
				"Spy Fiction",
				"World Heroes Anthology",
				"Grandia III",
				"Kingdom Hearts",
				"Radiata Stories",
				"Valkyrie Profile 2: Silmeria"};
		
		String[] subjectlabel={"Aruze","Aruze","Aruze","Atlus","Atlus","Atlus","Atlus","Atlus","Atlus",
				"KOEI", "KOEI", "KOEI", "KOEI", "KOEI", "Konami","Namco","Namco","Bandai Namco","Sammy Studios",
				"SNK Playmore","Square Enix","Square Enix","Square Enix","Square Enix"};

		String[] subject={"http://shadowhearts.wikia.com/wiki/Aruze",
				"http://shadowhearts.wikia.com/wiki/Aruze",
				"http://shadowhearts.wikia.com/wiki/Aruze",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Atlus",
				"https://en.wikipedia.org/wiki/Koei",
				"https://en.wikipedia.org/wiki/Koei",
				"https://en.wikipedia.org/wiki/Koei",
				"https://en.wikipedia.org/wiki/Koei",
				"https://en.wikipedia.org/wiki/Koei",
				"https://en.wikipedia.org/wiki/Konami",
				"https://en.wikipedia.org/wiki/Namco",
				"https://en.wikipedia.org/wiki/Namco",
				"https://en.wikipedia.org/wiki/Bandai_Namco_Entertainment",
				"https://en.wikipedia.org/wiki/Sega_Sammy_Holdings",
				"https://en.wikipedia.org/wiki/SNK",
				"https://en.wikipedia.org/wiki/Square_Enix",
				"https://en.wikipedia.org/wiki/Square_Enix",
				"https://en.wikipedia.org/wiki/Square_Enix",
				"https://en.wikipedia.org/wiki/Square_Enix"
				};
		
		String typ1="Publisher";
		String typ2="Spiel";
		String praedikat="veroeffentlicht";
		
		try	{
			FileWriter fw = new FileWriter("Z:/Desktop/Semantic Web/rdf_format/Publisher.rdf",false); 
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
			bw.append("\r\n");
			bw.append("<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
			bw.append("\r\n");
			bw.append("xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\"");
			bw.append("\r\n");
			bw.append("xmlns:xsd= \"http://www.w3.org/2001/XMLSchema#\"");
			bw.append("\r\n");
			bw.append("xmlns:dbp=\"http://dbpedia.org/property/\"");
			bw.append("\r\n");
			bw.append("xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\">");
			bw.append("\r\n");
			bw.append("\r\n");
			
			for(int i=0;i<24;i++){
				// rdf_maker aufgerufen, um Charaktere der obrigen Spiele zu parsen und in RDF-Format zu speichern 
				rdf_maker (subject[i],praedikat,subjectlabel[i],object[i],objectlabel[i],typ1,typ2,bw);
			}
			
			bw.append("</rdf:RDF>");
			bw.close();	
			
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}	
	
	static void rdf_maker (String subject, String praedikat, String subjectlabel,String object,String objectlabel, String typ1, String typ2, BufferedWriter bw) {	
		try{
			//in Datei schreiben
			bw.append("<rdf:"+typ1+" rdf:about=\""+subject+"\">");
			bw.append("\r\n");
			bw.append("<rdfs:label xml:lang=\"de\">"+subjectlabel+"</rdfs:label>");
			bw.append("\r\n");
			bw.append("<dbp:"+praedikat+">");
			bw.append("\r\n");
			bw.append("<rdf:"+typ2+" rdf:about=\""+object+"\"> <dbp:name>"+objectlabel+"</dbp:name>");
			bw.append("\r\n");
			bw.append("</rdf:"+typ2+">");
			bw.append("\r\n");
			bw.append("</dbp:"+praedikat+">");
			bw.append("\r\n");
			bw.append("</rdf:"+typ1+">");
			bw.append("\r\n");
			bw.append("\r\n");
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}
	}
	
}