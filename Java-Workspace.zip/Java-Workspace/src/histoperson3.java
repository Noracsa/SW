
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.*;
import java.util.regex.Pattern;


public class histoperson3 {
	//nur historische Personen von geboren.am
	
	public static void main(String[] args) {
		String link="http://geboren.am/namen/";
		String grundterm="http://geboren.am";
		String[] abc={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		String platzierung = "body div li a.bub-b-top";
		
		String typ1="Person";
		String typ2="Kategorie";
		String praedikat="gehoertzu";
		
		try	{
			FileWriter fw = new FileWriter("Z:/Desktop/Semantic Web/rdf_format/histo_Personen3.rdf",false);//h�ngt Daten unten an Datei an 
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
			bw.append("\r\n");
			bw.append("<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
			bw.append("\r\n");
			bw.append("xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\"");
			bw.append("\r\n");
			bw.append("xmlns:xsd= \"http://www.w3.org/2001/XMLSchema#\"");
			bw.append("\r\n");
			bw.append("xmlns:dbp=\"http://dbpedia.org/property/\"");
			bw.append("\r\n");
			bw.append("xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\">");
			bw.append("\r\n");
			bw.append("\r\n");
			
			rdf_maker (link,praedikat,typ1,typ2,platzierung,grundterm,abc ,bw);
			
			bw.append("</rdf:RDF>");
			bw.close();	
			
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}	
	
	static void rdf_maker (String link2, String praedikat, String typ1, String typ2, String platzierung,String grundterm,String[] abc,  BufferedWriter bw) {
		try	{
			int anz=0;
			for(int j=0;j<26;j++){
				
				String link=(link2+abc[j]);
				Document doc = Jsoup.connect(link).get();
				Elements charaktere = doc.select(platzierung);

				String subjectlabel2;
				String subject;
				String object;
				String objectlabel;
			
				for (int i=32+25;i<charaktere.size()-27;i++){
					Elements charaktere2 = charaktere.eq(i);
					subjectlabel2 = charaktere2.attr("Title"); 
					subject = (grundterm+charaktere2.attr("Href")); 
					String[] subjectlabel = subjectlabel2.split( Pattern.quote( "(" ) );
					//System.out.println(subjectlabel2);
								
					if(subjectlabel[1].length()>5){
						objectlabel="historische Person";
						object="http://geboren.am/";
						anz=anz+1;
				
						//in Datei schreiben
						bw.append("<rdf:"+typ1+" rdf:about=\""+subject+"\">");
						bw.append("\r\n");
						bw.append("<rdfs:label xml:lang=\"de\">"+subjectlabel[0]+"</rdfs:label>");
						bw.append("\r\n");
						bw.append("<dbp:"+praedikat+">");
						bw.append("\r\n");
						bw.append("<rdf:"+typ2+" rdf:about=\""+object+"\"> <dbp:name>"+objectlabel+"</dbp:name>");
						bw.append("\r\n");
						bw.append("</rdf:"+typ2+">");
						bw.append("\r\n");
						bw.append("</dbp:"+praedikat+">");
						bw.append("\r\n");
						bw.append("</rdf:"+typ1+">");
						bw.append("\r\n");
						bw.append("\r\n");
					}
				}	
			}
			System.out.println(anz);
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}
	
}