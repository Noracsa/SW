
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.*;


public class charaktere2 {
	//Erg�nzungen
	public static void main(String[] args) {
		String[] subject={
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Dynasty_Warriors_(series)",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Kessen",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Warriors_Orochi",
				"http://koei.wikia.com/wiki/Samurai_Warriors",
				"http://koei.wikia.com/wiki/Samurai_Warriors",
				"http://koei.wikia.com/wiki/Samurai_Warriors",
				"http://koei.wikia.com/wiki/Samurai_Warriors",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_I:_Der_Wille_zur_Macht",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_I:_Der_Wille_zur_Macht",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_I:_Der_Wille_zur_Macht",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_II:_Jenseits_von_Gut_und_B%C3%B6se",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_II:_Jenseits_von_Gut_und_B%C3%B6se",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_II:_Jenseits_von_Gut_und_B%C3%B6se",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_III:_Also_sprach_Zarathustra",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_III:_Also_sprach_Zarathustra",
				"http://xenosaga.wikia.com/wiki/Xenosaga_Episode_III:_Also_sprach_Zarathustra"
				};
		String[] subjectlabel={
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Dynasty Warriors",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Kessen",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Warriors Orochi",
				"Samurai Warriors",
				"Samurai Warriors",
				"Samurai Warriors",
				"Samurai Warriors",
				"Xenosaga: Episode I - Der Wille zur Macht",
				"Xenosaga: Episode I - Der Wille zur Macht",
				"Xenosaga: Episode I - Der Wille zur Macht",
				"Xenosaga: Episode II - Jenseits von Gut und B�se",
				"Xenosaga: Episode II - Jenseits von Gut und B�se",
				"Xenosaga: Episode II - Jenseits von Gut und B�se",
				"Xenosaga: Episode III - Also Sprach Zarathustra",
				"Xenosaga: Episode III - Also Sprach Zarathustra",
				"Xenosaga: Episode III - Also Sprach Zarathustra"};
		String[] link={
				"http://koei.wikia.com/wiki/Category:Wu_Characters",
				"http://koei.wikia.com/wiki/Category:Wu_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Wei_Characters",
				"http://koei.wikia.com/wiki/Category:Wei_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Shu_Characters",
				"http://koei.wikia.com/wiki/Category:Shu_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Other_Characters",
				"http://koei.wikia.com/wiki/Category:Other_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Jin_Characters",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=4",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=5",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=6",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=7",
				"http://koei.wikia.com/wiki/Category:Wei_Non-Playable_Characters?page=8",
				"http://koei.wikia.com/wiki/Category:Wu_Non-Playable_Characters",
				"http://koei.wikia.com/wiki/Category:Wu_Non-Playable_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Wu_Non-Playable_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=4",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=5",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=6",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=7",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=8",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=9",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=10",
				"http://koei.wikia.com/wiki/Category:Other_Non-Playable_Characters?page=11",
				"http://koei.wikia.com/wiki/Category:Jin_Non-Playable_Characters",
				"http://koei.wikia.com/wiki/Category:Jin_Non-Playable_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Shu_Non-Playable_Characters",
				"http://koei.wikia.com/wiki/Category:Shu_Non-Playable_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Shu_Non-Playable_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Shu_Non-Playable_Characters?page=4",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=4",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=5",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=6",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=7",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=8",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=9",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=10",
				"http://koei.wikia.com/wiki/Category:Kessen_Characters?page=11",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=4",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=5",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=6",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=7",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=8",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=9",
				"http://koei.wikia.com/wiki/Category:Warriors_Orochi_Characters?page=10",
				"http://koei.wikia.com/wiki/Category:Samurai_Warriors_Characters",
				"http://koei.wikia.com/wiki/Category:Samurai_Warriors_Characters?page=2",
				"http://koei.wikia.com/wiki/Category:Samurai_Warriors_Characters?page=3",
				"http://koei.wikia.com/wiki/Category:Samurai_Warriors_Characters?page=4",
				"http://xenosaga.wikia.com/wiki/Category:Episode_I_characters",
				"http://xenosaga.wikia.com/wiki/Category:Episode_I_characters?page=2",
				"http://xenosaga.wikia.com/wiki/Category:Episode_I_characters?page=3",
				"http://xenosaga.wikia.com/wiki/Category:Episode_II_characters",
				"http://xenosaga.wikia.com/wiki/Category:Episode_II_characters?page=2",
				"http://xenosaga.wikia.com/wiki/Category:Episode_II_characters?page=3",
				"http://xenosaga.wikia.com/wiki/Category:Episode_III_characters",
				"http://xenosaga.wikia.com/wiki/Category:Episode_III_characters?page=2",
				"http://xenosaga.wikia.com/wiki/Category:Episode_III_characters?page=3"
				};
		String[] grundterm={""};
		String[] platzierung = {
				"section div article div div div div div div div div a"};
		
		String typ1="Spiel";
		String typ2="Charakter";
		String praedikat="hascharakter";
		
		try	{
			FileWriter fw = new FileWriter("Z:/Desktop/Semantic Web/rdf_format/Charaktere2.rdf",false);//h�ngt Daten unten an Datei an 
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
			bw.append("\r\n");
			bw.append("<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
			bw.append("\r\n");
			bw.append("xmlns:rdfs=\"http://www.w3.org/2000/01/rdf-schema#\"");
			bw.append("\r\n");
			bw.append("xmlns:xsd= \"http://www.w3.org/2001/XMLSchema#\"");
			bw.append("\r\n");
			bw.append("xmlns:dbp=\"http://dbpedia.org/property/\"");
			bw.append("\r\n");
			bw.append("xmlns:geo=\"http://www.w3.org/2003/01/geo/wgs84_pos#\">");
			bw.append("\r\n");
			bw.append("\r\n");
			
			for(int i=0;i<71;i++){
			// hier wird die funktion rdf_maker aufgerufen, um Charaktere der obrigen Spiele zu parsen und in RDF-Format zu speichern 
			rdf_maker (link[i],subject[i],praedikat,subjectlabel[i], grundterm[0],typ1,typ2,platzierung[0],bw);
			}
			
			bw.append("</rdf:RDF>");
			bw.close();	
			
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}	
	
	static void rdf_maker (String link,String subject, String praedikat, String subjectlabel,String grundterm, String typ1, String typ2, String platzierung, BufferedWriter bw) {
		try	{
			Document doc = Jsoup.connect(link).get();
			Elements charaktere = doc.select(platzierung);
			
			String[] objectlabel=new String[charaktere.size()];
			String[] object=new String[charaktere.size()];
			
			for (int i=0;i<charaktere.size();i++){
				Elements charaktere2 = charaktere.eq(i);
				objectlabel[i] = charaktere2.attr("Title"); 
				object[i] = (grundterm+charaktere2.attr("Href")); 
				System.out.println(objectlabel[i]);
				
				//in Datei schreiben
				bw.append("<rdf:"+typ1+" rdf:about=\""+subject+"\">");
				bw.append("\r\n");
				bw.append("<rdfs:label xml:lang=\"de\">"+subjectlabel+"</rdfs:label>");
				bw.append("\r\n");
				bw.append("<dbp:"+praedikat+">");
				bw.append("\r\n");
				bw.append("<rdf:"+typ2+" rdf:about=\""+object[i]+"\"> <dbp:name>"+objectlabel[i]+"</dbp:name>");
				bw.append("\r\n");
				bw.append("</rdf:"+typ2+">");
				bw.append("\r\n");
				bw.append("</dbp:"+praedikat+">");
				bw.append("\r\n");
				bw.append("</rdf:"+typ1+">");
				bw.append("\r\n");
				bw.append("\r\n");
			}
		}
		catch(Exception e){
			System.out.println("Fehler:\t"+e.toString());
		}	
	}
	
}
